//
//  ViewController.swift
//  MapApp
//
//  Created by Zhanserik on 6/19/17.
//  Copyright © 2017 Kenes Inc. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {

    @IBOutlet var mapView: MKMapView!
    var locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.requestAlwaysAuthorization()
    
        mapView.showsUserLocation = true
        mapView.userTrackingMode = .follow
        mapView.showsPointsOfInterest = true
        mapView.delegate = self
        
        let place = Place()
        place.coordinate = CLLocationCoordinate2D(latitude: 51.55, longitude: -0.122)
        place.title = "Beer Bar"
        place.subtitle = "West ave."
        
        mapView.addAnnotation(place)
    }
    
}
extension ViewController: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        let annotation = view.annotation
        
        let userLocation = mapView.userLocation.location
        
        let annotationLocation = CLLocation(latitude: (annotation?.coordinate.latitude)!, longitude: (annotation?.coordinate.longitude)!)
        
        print(userLocation?.distance(from: annotationLocation) ?? "")
        
    }
}
