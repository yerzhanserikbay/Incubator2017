//
//  TableViewController.swift
//  Constraints
//
//  Created by Zhanserik on 6/27/17.
//  Copyright © 2017 Kenes Inc. All rights reserved.
//

import UIKit

class TableViewController: UIViewController {

    let tableView = UITableView()
    var someString = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.frame = CGRect(x: 00, y: 0, width: self.view.frame.width, height: 500)
        tableView.dataSource = self
        tableView.delegate = self
        self.view.addSubview(tableView)
    }
}

extension TableViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 100
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let identifier = "identifier"
        
        var cell = tableView.dequeueReusableCell(withIdentifier: identifier)
        
        if cell == nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: identifier)
        }
        cell?.textLabel?.text = "Hello"
        return cell!
    }
}
extension TableViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("222")
    }
}
