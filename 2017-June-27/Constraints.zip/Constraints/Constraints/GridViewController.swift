//
//  GridViewController.swift
//  Constraints
//
//  Created by Zhanserik on 6/27/17.
//  Copyright © 2017 Kenes Inc. All rights reserved.
//

import UIKit
import EasyPeasy

class GridViewController: UIViewController {

    lazy var layout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 1
        layout.minimumInteritemSpacing = 1
        
        let size: CGFloat = (self.view.frame.width / 3) - 2
        layout.itemSize = CGSize(width: size, height: size)
        return layout
    }()
    
    lazy var collectionView: UICollectionView = {
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: self.layout)
        
        collectionView.register(ImageCollectionViewCell.self, forCellWithReuseIdentifier: "ImageCollectionViewCell")
        collectionView.dataSource = self
        return collectionView
    }()
    
    
    private func setupViews(){
        self.view.addSubview(collectionView)
        collectionView.dataSource = self
    }
    
    private func setupLayouts(){
        collectionView <- [
            Edges(0)
        ]
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
        setupLayouts()
        // Do any additional setup after loading the view.
    }
}

extension GridViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 100
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCollectionViewCell", for: indexPath) as! ImageCollectionViewCell
        
        cell.imageView.backgroundColor = .orange
        
        return cell
    }
}
