//
//  ViewController.swift
//  Constraints
//
//  Created by Zhanserik on 6/27/17.
//  Copyright © 2017 Kenes Inc. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor(white: 0.7, alpha: 1.0)
        
        let button = UIButton()
        
        button.frame = CGRect(x: 50, y: 100, width: 50, height: 50)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 30)
        button.setTitle("Hey", for: .normal)
        button.setTitle("Yo", for: .highlighted)
        button.setTitleColor(.red, for: .normal)
        button.setTitleColor(.yellow, for: .highlighted)
        button.addTarget(self, action: #selector(tapAction(sender:)), for: .touchUpInside)
        
        button.setTitleColor(.purple, for: .selected)
        button.setTitle("Wow", for: .selected)
        button.layer.cornerRadius = 25
        button.layer.masksToBounds = true
        button.backgroundColor = .yellow
        
        self.view.addSubview(button)
        
        
        let label = UILabel()
        label.frame = CGRect(x: 0, y: 150, width: self.view.frame.width, height: 50)
        label.numberOfLines = 0
        label.textColor = .red
        label.text = "Lorem Ipsum"
        label.textAlignment = .right
        label.backgroundColor = .white
        
        self.view.addSubview(label)
        
        label.layer.cornerRadius = 25
        label.layer.masksToBounds = true
    }
    
    func tapAction(sender: UIButton){
        sender.isSelected = true
        
        let vc = GridViewController()
//        vc.someString = "Other string"
        self.navigationController?.pushViewController(vc, animated: true)
//        vc
        
//        self.present(vc, animated: true, completion: nil)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

