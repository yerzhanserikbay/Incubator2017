//
//  ImageCollectionViewCell.swift
//  Constraints
//
//  Created by Zhanserik on 6/27/17.
//  Copyright © 2017 Kenes Inc. All rights reserved.
//

import UIKit
import EasyPeasy

class ImageCollectionViewCell: UICollectionViewCell {
    let imageView = UIImageView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        
        
        self.contentView.addSubview(imageView)
        imageView <- [
            Edges(0)
        ]
//        imageView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[imageView]-0-|", options: .alignAllTop, metrics: nil, views: ["imageView" : imageView]))
//       imageView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[imageView]-0-|", options: .alignAllTop, metrics: nil, views: ["imageView" : imageView]))
//        
//    //Carthography
//    //EasyPeasy
//    //Masonry
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
