//
//  Person+CoreDataClass.swift
//  Contacts
//
//  Created by Zhanserik on 6/26/17.
//  Copyright © 2017 Kenes Inc. All rights reserved.
//

import Foundation
import CoreData

@objc(Person)
public class Person: NSManagedObject {

}
