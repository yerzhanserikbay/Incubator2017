//
//  FeedTableViewCell.swift
//  FeedApp
//
//  Created by Zhanserik on 6/26/17.
//  Copyright © 2017 Kenes Inc. All rights reserved.
//

import UIKit

class FeedTableViewCell: UITableViewCell {
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.imageView?.image = UIImage(named: "music-player")
//        self.imageView?.frame = CGRect(x: 10, y: 15, width: 50, height: 50)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
